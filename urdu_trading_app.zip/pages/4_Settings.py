
import streamlit as st

st.title("سیٹنگز")
st.markdown("یہاں پر آپ ایپ کی سیٹنگز تبدیل کر سکتے ہیں۔")
