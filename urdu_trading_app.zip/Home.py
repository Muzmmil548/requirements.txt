
import streamlit as st

st.set_page_config(page_title="اردو ٹریڈنگ اسسٹنٹ", layout="wide")
st.title("خوش آمدید اردو ٹریڈنگ ایپ میں")
st.markdown("براہ کرم بائیں طرف مینو سے ایک آپشن منتخب کریں۔")
